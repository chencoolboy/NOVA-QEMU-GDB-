#pragma once

#include "types.h"
#include "cpu.h"

class Pte
{
    private:

        mword v;

        enum {
            PTE_P = 1 << 0,     // present
            PTE_W = 1 << 1,     // writble
            PTE_U = 1 << 2,     // user accessible

            PTE_A = 1 << 5,     // accessed
            PTE_D = 1 << 6,     // dirty
            PTE_S = 1 << 7,     // super page
            PTE_G = 1 << 8,     // global
        };

    public:
};

class Ptab
{
    public:

        static void insert_mapping (mword virt, mword phys, mword attr);

        static void * remap (mword addr);
};
