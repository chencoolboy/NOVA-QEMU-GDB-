#define NORETURN            __attribute__((noreturn))
#define EXTERN_C            extern "C"

unsigned syscall1 (unsigned w0)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : : "ecx", "edx");
    return w0;
}

unsigned syscall2 (unsigned w0, unsigned w1)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : "S" (w1) : "ecx", "edx");
    return w0;
}

// example syscall for yielding
unsigned syscall3 (unsigned w0, unsigned w1, unsigned w2)
{
    asm volatile (
                  "   mov %%esp, %%ecx    ;"
                  "   mov $1f, %%edx      ;"
                  "   sysenter            ;"
                  "1:                     ;"
                  : "+a" (w0) : "S" (w1), "D" (w2) : "ecx", "edx");
    return w0;
}

void sys_create_ec (void (*eip)(), void* esp)
{
    syscall3 (1, reinterpret_cast<unsigned>(eip), reinterpret_cast<unsigned>(esp));
}

unsigned sys_yield()
{
    //return syscall1 (0xdeadbeaf /* TODO use correct syscall number*/);
    return syscall1 (2);
}

NORETURN
void thread()
{
    while (1) sys_yield();
}
 
EXTERN_C NORETURN
void main_func ()
{
    char stack[512];

    for (int i = 1; i <= 8; i++) {
        sys_create_ec (thread, stack + i * 64);
        sys_yield ();
    }

    while (1) ;
}
