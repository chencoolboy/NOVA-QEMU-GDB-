#define NORETURN __attribute__((noreturn))
#define EXTERN_C extern "C"
int func()
{
 return 2;
}
EXTERN_C NORETURN

void main_func ()
{
    func();
    while (1) ;
}

