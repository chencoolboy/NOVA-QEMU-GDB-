#include "compiler.h"

USER
unsigned syscall1 (unsigned w0)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   and $0xfff, %%edx   ;"
        "   add $0x2000, %%edx  ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : : "ecx", "edx");
    return w0;
}

USER
unsigned syscall3 (unsigned w0, unsigned w1, unsigned w2)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   and $0xfff, %%edx   ;"
        "   add $0x2000, %%edx  ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : "S" (w1), "D" (w2) : "ecx", "edx");
    return w0;
}

USER
unsigned sys_nop()
{
    return syscall1 (0);
}

USER
unsigned sys_add (unsigned a, unsigned b)
{
    return syscall3 (1,a,b);
}

EXTERN_C REGPARM(1) NORETURN USER
void usercode (unsigned)
{
    sys_nop();
    sys_add(2,3);

    while (1) ;
}
