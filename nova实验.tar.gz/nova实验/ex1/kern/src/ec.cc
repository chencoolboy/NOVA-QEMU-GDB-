/*
 * Execution Context
 *
 * Copyright (C) 2009-2011 Udo Steinberg <udo@hypervisor.org>
 * Economic rights: Technische Universitaet Dresden (Germany)
 *
 * This file is part of the NOVA microhypervisor.
 *
 * NOVA is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * NOVA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License version 2 for more details.
 */

#include "bits.h"
#include "ec.h"
#include "assert.h"
#include "cpu.h"
#include "ptab.h"

Ec * Ec::current;

// used for idle() and root_invoke()
Ec::Ec (void (*f)(), mword mbi) : cont (f)
{
    regs.eax = mbi;
    regs.cs  = SEL_USER_CODE;
    regs.ds  = SEL_USER_DATA;
    regs.es  = SEL_USER_DATA;
    regs.ss  = SEL_USER_DATA;
    regs.efl = 0x200;           // IF = 1
}

// only used by syscall create thread (EC+SC)
Ec::Ec (mword eip)
{
    cont = ret_user_iret;
    regs.cs  = SEL_USER_CODE;
    regs.ds  = SEL_USER_DATA;
    regs.es  = SEL_USER_DATA;
    regs.ss  = SEL_USER_DATA;
    regs.efl = 0x200;           // IF = 1
    regs.eip = eip;
}

void Ec::ret_user_sysexit()
{
    asm volatile ("lea %0, %%esp;"
                  "popa;"
                  "sti;"
                  "sysexit"
                  : : "m" (current->regs) : "memory");

    UNREACHED;
}

void Ec::ret_user_iret()
{
    asm volatile ("lea %0, %%esp;"
                  "popa;"
                  "pop %%gs;"
                  "pop %%fs;"
                  "pop %%es;"
                  "pop %%ds;"
                  "add $8, %%esp;"
                  "iret"
                  : : "m" (current->regs) : "memory");

    UNREACHED;
}

void Ec::idle()
{
    for (;;)

    UNREACHED;
}

EXTERN_C
void usercode ();

void Ec::root_invoke()
{
    mword code = reinterpret_cast<mword>(&usercode);

    Ptab::insert_mapping (    PAGE_SIZE, Kalloc::virt2phys (Kalloc::allocator.alloc_page(1)), 0x7);
    Ptab::insert_mapping (2 * PAGE_SIZE, Kalloc::virt2phys (reinterpret_cast<void*>(code)), 0x7);

    code = (code & PAGE_MASK) + 2 * PAGE_SIZE;

    printf ("iret to user ...\n");

    // TODO prepare stack and iret to user
    mword stack[] = { code, SEL_USER_CODE, 0x202, 2 * PAGE_SIZE, SEL_USER_DATA };

    asm volatile (
        "mov %0, %%esp   ;"
        "iret            ;"
        : : "r" (stack) : "memory");


    FAIL;

    UNREACHED;
}

void Ec::handle_tss()
{
    panic ("Task gate invoked\n");
}

void Ec::syscall_handler (uint8 n)
{
    printf ("syscall %d\n", n);
    Sys_regs * r = current->sys_regs();

    switch (n) {

    case 0: // nop
        printf ("syscall %d - nop\n", n);
        break;

    case 1: // add
        printf ("syscall %d - add : %lu + %lu\n", n, r->esi, r->edi);
        r->esi += r->edi;
        break;

    default:
        printf ("syscall %d - unknown\n", n);
        break;
    };
    ret_user_sysexit();

    UNREACHED;
}

bool Ec::handle_exc_ts (Exc_regs *r)
{
    if (r->user())
        return false;

    // SYSENTER with EFLAGS.NT=1 and IRET faulted
    r->efl &= ~0x4000; // nested task eflag

    return true;
}

void Ec::handle_exc (Exc_regs *r)
{
    printf ("Ec::handle_exc %#lx (eip=%#lx cr2=%#lx)\n", r->vec, r->eip, r->cr2);

    if (r->vec == Cpu::EXC_TS && handle_exc_ts (r))
        return;

    panic ("unhandled kernel exception\n");
}
