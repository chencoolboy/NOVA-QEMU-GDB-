#define NORETURN __attribute__((noreturn))
#define EXTERN_C extern "C"

EXTERN_C NORETURN
void main_func ()
{

    while (1) ;
}
